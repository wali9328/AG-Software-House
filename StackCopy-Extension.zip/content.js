document.addEventListener("keydown", (event) => {
  if (event.altKey && event.key.toLowerCase() === "c") {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText) {
      try {
        chrome.runtime.sendMessage(
          { action: "add_to_stack", text: selectedText },
          (response) => {
            if (chrome.runtime.lastError) return;
            if (response && response.status === "success") {
              showToast(`Saved to Stack! (${response.count} items)`);
            } else if (response && response.status === "expired") {
              showToast("❌ 3-Day Trial Expired! Open extension menu to unlock.", "#dc3545");
            }
          }
        );
      } catch (err) {
        showToast("Extension updated! Please refresh this page.", "#dc3545");
      }
    }
  }
});

// Listen for successful image saves from background execution
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "image_saved") {
    showToast(`🖼️ Image Saved to Stack! (${message.count} items)`);
  }
});

function showToast(message, bgColor = "#28a745") {
  let toast = document.createElement("div");
  toast.innerText = message;
  toast.style.position = "fixed";
  toast.style.top = "20px";
  toast.style.right = "20px";
  toast.style.backgroundColor = bgColor;
  toast.style.color = "white";
  toast.style.padding = "10px 20px";
  toast.style.borderRadius = "5px";
  toast.style.zIndex = "10000";
  toast.style.fontFamily = "Arial, sans-serif";
  toast.style.fontSize = "14px";
  toast.style.boxShadow = "0px 4px 6px rgba(0,0,0,0.1)";
  document.body.appendChild(toast);
  setTimeout(() => { toast.remove(); }, 2500);
}
