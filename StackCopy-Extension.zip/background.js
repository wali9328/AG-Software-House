// Build right-click context menu options upon installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["installDate", "isActivated"], (data) => {
    if (!data.installDate) {
      chrome.storage.local.set({ installDate: Date.now(), isActivated: false });
    }
  });

  chrome.contextMenus.create({
    id: "stack_image",
    title: "🖼️ Stack this Image",
    contexts: ["image"]
  });
});

// Handle right-click context selection events
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "stack_image" && info.srcUrl) {
    chrome.storage.local.get({ copyStack: [] }, (data) => {
      let currentStack = Array.isArray(data.copyStack) ? data.copyStack : [];
      currentStack.push({ type: "image", value: info.srcUrl });
      
      chrome.storage.local.set({ copyStack: currentStack }, () => {
        chrome.tabs.sendMessage(tab.id, { action: "image_saved", count: currentStack.length });
      });
    });
  }
});

// CENTRAL ENGINE: Handlers for Clipboard Stacking and Live API proxy validation
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Action A: Add items to copy stack
  if (request.action === "add_to_stack") {
    chrome.storage.local.get(["installDate", "isActivated", "copyStack"], (data) => {
      const isActivated = data.isActivated || false;
      const installDate = data.installDate || Date.now();
      let currentStack = Array.isArray(data.copyStack) ? data.copyStack : [];

      const threeDaysInMs = 3 * 24 * 60 * 60 * 1000;
      if ((Date.now() - installDate) > threeDaysInMs && !isActivated) {
        sendResponse({ status: "expired" });
        return;
      }

      currentStack.push({ type: "text", value: request.text });
      chrome.storage.local.set({ copyStack: currentStack }, () => {
        sendResponse({ status: "success", count: currentStack.length });
      });
    });
    return true;
  }

  // Action B: High-Privilege Server Handshake with Lemon Squeezy Firewall
  if (request.action === "verify_license_api") {
    const requestBody = new URLSearchParams();
    requestBody.append("license_key", request.licenseKey);
    requestBody.append("instance_name", "Desktop Extension Workspace User");

    fetch("https://api.lemonsqueezy.com/v1/licenses/activate", {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: requestBody.toString()
    })
    .then(async (response) => {
      const text = await response.text();
      try {
        const json = JSON.parse(text);
        sendResponse({ success: response.ok, data: json });
      } catch (e) {
        sendResponse({ success: false, error: "Server format mismatch. Please verify Test Mode status." });
      }
    })
    .catch((err) => {
      sendResponse({ success: false, error: "Unable to connect to verification servers." });
    });

    return true; // Keep asynchronous bridge channel open
  }
});
