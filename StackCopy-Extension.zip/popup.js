const listDiv = document.getElementById("stack-list");
const toast = document.getElementById("toast");
const contextMenu = document.getElementById("context-menu");
const copyLinkOption = document.getElementById("copy-link-option");
const searchInput = document.getElementById("search-input");
let activeImageUrl = ""; 

function checkOnboardingAndRender() {
  chrome.storage.local.get(["installDate", "isActivated", "trialStarted", "copyStack"], (data) => {
    const isActivated = data.isActivated || false;
    const trialStarted = data.trialStarted || false;
    const installDate = data.installDate || Date.now();
    const currentStack = data.copyStack || [];

    const threeDaysInMs = 3 * 24 * 60 * 60 * 1000;
    const trialExpired = trialStarted && (Date.now() - installDate) > threeDaysInMs;

    // SCENARIO 1: Brand New Installation / Onboarding
    if (!trialStarted && !isActivated) {
      searchInput.style.display = "none"; 
      listDiv.innerHTML = `
        <div style="text-align: center; padding: 15px 5px;">
          <h4 style="color:#007bff; margin-top:0; margin-bottom:8px;">🚀 Welcome to StackCopy!</h4>
          <p style="font-size:12px; color:#555; line-height:1.4; margin-bottom:15px;">Choose how you want to experience unlimited copying:</p>
          <button id="start-trial-btn" style="width:100%; padding:10px; background:#f1f3f5; color:#212529; border:1px solid #ced4da; border-radius:6px; font-size:13px; cursor:pointer; font-weight:bold; margin-bottom:10px;">⏱️ Start 3-Day Free Trial</button>
          <div style="border-top: 1px dashed #dee2e6; margin: 15px 0;"></div>
          <a href="https://agsoftwarehouse.lemonsqueezy.com/checkout/buy/c51856f8-672c-4939-883d-b5730bcab137" id="buy-link-early" target="_blank" style="display:block; text-align:center; background:#28a745; color:white; padding:10px; text-decoration:none; border-radius:6px; font-weight:bold; font-size:13px; margin-bottom:12px;">🛒 Buy Lifetime License Key</a>
          <div style="display:flex; gap:5px; margin-top:10px;">
            <input type="text" id="key-input-early" placeholder="Enter License Key" style="width:70%; padding:6px; border:1px solid #ced4da; border-radius:4px; font-size:12px;">
            <button id="activate-btn-early" style="width:30%; padding:6px; background:#007bff; color:white; border:none; border-radius:4px; font-size:12px; cursor:pointer; font-weight:bold;">Verify</button>
          </div>
          <p id="error-msg-early" style="color:#dc3545; font-size:11px; margin-top:5px; display:none; font-weight:bold;">Verifying License Key...</p>
        </div>
      `;
      
      document.getElementById("start-trial-btn").onclick = () => {
        chrome.storage.local.set({ trialStarted: true, installDate: Date.now() }, () => { location.reload(); });
      };
      
      document.getElementById("activate-btn-early").onclick = () => {
        const inputKey = document.getElementById("key-input-early").value.trim();
        validateWithLemonSqueezy(inputKey, "error-msg-early");
      };
      return;
    }

    // SCENARIO 2: Trial Expired & Unactivated Paywall
    if (trialExpired && !isActivated) {
      searchInput.style.display = "none";
      listDiv.innerHTML = `
        <div style="text-align: center; padding: 20px 10px;">
          <h4 style="color:#dc3545; margin-top:0;">⏳ Trial Period Finished</h4>
          <p style="font-size:12px; color:#666; line-height:1.4; margin-bottom:15px;">Your 3-day evaluation window has concluded. Purchase a lifetime license key to regain unlimited copying options.</p>
          <a href="https://agsoftwarehouse.lemonsqueezy.com/checkout/buy/c51856f8-672c-4939-883d-b5730bcab137" id="buy-link-expired" target="_blank" style="display:block; text-align:center; background:#28a745; color:white; padding:10px; text-decoration:none; border-radius:6px; font-weight:bold; font-size:13px; margin-bottom:15px;">🛒 Get Lifetime License Key</a>
          
          <div style="margin-top: 15px; border-top: 1px dashed #dee2e6; padding-top: 15px;">
            <div style="display:flex; gap:5px;">
              <input type="text" id="key-input-expired" placeholder="Paste Your License Key Here" style="width:70%; padding:6px; border:1px solid #ced4da; border-radius:4px; font-size:12px;">
              <button id="activate-btn-expired" style="width:30%; padding:6px; background:#007bff; color:white; border:none; border-radius:4px; font-size:12px; cursor:pointer; font-weight:bold;">Activate</button>
            </div>
            <p id="error-msg-expired" style="color:#dc3545; font-size:11px; margin-top:5px; display:none; font-weight:bold;">Verifying License Key...</p>
          </div>
        </div>
      `;
      
      document.getElementById("activate-btn-expired").onclick = () => {
        const inputKey = document.getElementById("key-input-expired").value.trim();
        validateWithLemonSqueezy(inputKey, "error-msg-expired");
      };
      return;
    }
    // SCENARIO 3: Active Premium Dashboard View / Clipboard Interface
    searchInput.style.display = "block"; 
    listDiv.innerHTML = ""; 
    if (currentStack.length === 0) {
      listDiv.innerHTML = `<div class="empty-state">Your stack is empty.<br>Press <b>Alt + C</b> for text or <b>Right-Click</b> images!</div>`;
      return;
    }

    for (let i = currentStack.length - 1; i >= 0; i--) {
      const item = currentStack[i];
      const card = document.createElement("div");
      card.className = "item-card";

      if (!item.type || item.type === "text") {
        const itemText = typeof item === "string" ? item : item.value;
        card.innerText = `${i + 1}. ${itemText}`;
        card.setAttribute("data-search-content", itemText.toLowerCase());
        
        card.onclick = () => {
          navigator.clipboard.writeText(itemText).then(() => showToastMessage("🎉 Premium Activated! Need custom updates, new extensions, or websites? AG Software House builds custom tools at a discounted price. Contact us via your storefront panel!"));
        };
      } 
      else if (item.type === "image") {
        card.style.height = "auto";
        card.style.maxHeight = "140px";
        card.setAttribute("data-search-content", "image imagelink picture URL info");
        card.innerHTML = `
          <div style="display:flex; flex-direction:column; gap:4px; align-items:center; width:100%;">
            <span style="font-size:11px; font-weight:bold; color:#28a745; align-self:flex-start;">🖼️ Image ${i + 1} (Left: Pixels / Right: Link)</span>
            <img src="${item.value}" style="max-width:100%; max-height:80px; border-radius:4px; object-fit:contain; border:1px solid #eee;">
          </div>
        `;
        
        card.onclick = () => {
          showToastMessage("Processing image pixels...");
          const img = new Image();
          img.crossOrigin = "anonymous"; 
          img.src = item.value;

          img.onload = () => {
            try {
              const canvas = document.createElement("canvas");
              canvas.width = img.naturalWidth;
              canvas.height = img.naturalHeight;
              const ctx = canvas.getContext("2d");
              ctx.drawImage(img, 0, 0);
              
              canvas.toBlob(async (blob) => {
                if (!blob) throw new Error("Canvas compilation failed");
                try {
                  await navigator.clipboard.write([
                    new ClipboardItem({ "image/png": blob })
                  ]);
                  showToastMessage("Image pixels copied! Ready to paste.");
                } catch (writeErr) {
                  fallbackToLink(item.value);
                }
              }, "image/png");
            } catch (err) {
              fallbackToLink(item.value);
            }
          };
          img.onerror = () => fallbackToLink(item.value);
        };

        card.oncontextmenu = (e) => {
          e.preventDefault(); 
          activeImageUrl = item.value; 
          contextMenu.style.top = `${e.pageY}px`;
          contextMenu.style.left = `${e.pageX}px`;
          contextMenu.style.display = "block";
        };
      }
      listDiv.appendChild(card);
    }
  });
}

// SECURE LIVE LEMON SQUEEZY LICENSE VALIDATOR
// SECURE SYSTEM METHOD: Routes key verification safely through background.js proxy
function validateWithLemonSqueezy(licenseKey, errorElementId) {
  const errorMsgElement = document.getElementById(errorElementId);
  errorMsgElement.style.color = "#007bff";
  errorMsgElement.innerText = "⏳ Verifying license security key...";
  errorMsgElement.style.display = "block";

  if (!licenseKey) {
    errorMsgElement.style.color = "#dc3545";
    errorMsgElement.innerText = "❌ Please enter your license key.";
    return;
  }

  // Send data to background worker to bypass extension popup request limitations
  chrome.runtime.sendMessage(
    { action: "verify_license_api", licenseKey: licenseKey },
    (response) => {
      if (chrome.runtime.lastError || !response) {
        errorMsgElement.style.color = "#dc3545";
        errorMsgElement.innerText = "❌ Verification proxy broken. Reload extension.";
        return;
      }

      if (response.success && response.data && response.data.activated === true) {
        // Legitimate key matched! Persist activated state permanently
        chrome.storage.local.set({ isActivated: true, savedLicenseKey: licenseKey }, () => {
          showToastMessage("🎉 Premium Activated! Need custom updates, new extensions, or websites? AG Software House builds custom tools at a discounted price. Contact us via your storefront panel!");
          location.reload(); 
        });
      } else {
        errorMsgElement.style.color = "#dc3545";
        // Show the direct error response coming back from Lemon Squeezy's system data
        const backendError = response.data ? response.data.error : null;
        errorMsgElement.innerText = `❌ ${backendError || response.error || "Invalid or deactivated license key."}`;
      }
    }
  );
}

searchInput.oninput = (e) => {
  const query = e.target.value.toLowerCase().trim();
  const cards = document.getElementsByClassName("item-card");
  
  for (let card of cards) {
    const searchContent = card.getAttribute("data-search-content") || "";
    if (searchContent.includes(query)) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }
  }
};

copyLinkOption.onclick = () => {
  if (activeImageUrl) {
    navigator.clipboard.writeText(activeImageUrl);
    showToastMessage("Image text link URL copied!");
  }
  contextMenu.style.display = "none";
};

document.onclick = () => { contextMenu.style.display = "none"; };

// Fallback logic
function fallbackToLink(url) {
  navigator.clipboard.writeText(url);
  showToastMessage("Protected source. Link copied instead!");
}

function showToastMessage(text = "Ready to paste!") {
  toast.innerText = text;
  toast.style.display = "block";
  setTimeout(() => { toast.style.display = "none"; }, 1800);
}

document.getElementById("clear").onclick = () => {
  chrome.storage.local.set({ copyStack: [] }, () => { checkOnboardingAndRender(); });
};

document.addEventListener("DOMContentLoaded", checkOnboardingAndRender);

